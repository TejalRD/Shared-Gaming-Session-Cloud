function init() {
  var draw,
    getC,
    DrawX,
    drawY,
    m_down = 0,
    drawxp,
    drawyp,
    painttype,
    drawSize,
    pict_id;
  var draw = document.getElementById("pict-page");
  var getC = draw.getContext("2d");

  var paint = false;
  var painter = {};
  var pointer = {};
  var user_names = {};
  var socket = io.connect("");
  var id = socket.id;
  if (draw.getContext) {
    getC = draw.getContext("2d");
    window.addEventListener("resize", resize_drawing, false);
    window.addEventListener("orientationchange", resize_drawing, false);
    resize_drawing();
  }
  function resize_drawing() {
    draw.width = window.innerWidth;
    draw.height = window.innerHeight;
  }

  draw.addEventListener("mousedown", m_down, false);
  draw.addEventListener("mousemove", cursor_xy, false);
  draw.addEventListener("touchstart", t_down, false);
  draw.addEventListener("touchmove", t_xy, true);
  draw.addEventListener("touchend", t_up, false);
  document.body.addEventListener("mouseup", m_up, false);
  document.body.addEventListener("touchcancel", t_up, false);

  function m_up() {
    m_down = 0;
    cursor_xy();
  }

  function t_up() {
    paint = false;
  }

  function m_down() {
    m_down = 1;
    cursor_xy();
  }

  function t_down(e) {
    paint = false;
    drawxp = e.targetTouches[0].pageX - draw.offsetLeft;
    drawyp = e.targetTouches[0].pageY - draw.offsetTop;
    cursor_xy();
  }
  function cursor_xy(e) {
    if (!e) e = event;
    DrawX = e.pageX - draw.offsetLeft;
    drawY = e.pageY - draw.offsetTop;
    if (m_down) {
      paint = true;
    }
    if (!m_down) {
      paint = false;
    }
    if (typeof painttype === "undefined") {
      painttype = "Line";
      strokeStyle = "Black";
      fillStyle = "Black";
      drawSize = 3;
    }

    drawing_data = {
      drawxp: drawxp,
      drawyp: drawyp,
      paint: paint,
      id: id,
      pict_id: pict_id,
      DrawX: DrawX,
      drawY: drawY,
      painttype: painttype,
      draw_strokeStyle: strokeStyle,
      draw_fillStyle: fillStyle,
      drawSize: drawSize,
    };
    socket.emit("pictionary_mousemove", drawing_data);

    if (paint) {
      picDraw(drawing_data);
    }

    drawxp = DrawX;
    drawyp = drawY;
  }

  function t_xy(e) {
    if (!e) e = event;
    e.preventDefault();
    DrawX = e.targetTouches[0].pageX - draw.offsetLeft;
    drawY = e.targetTouches[0].pageY - draw.offsetTop;
    if (typeof painttype === "undefined") {
      painttype = "Line";
      strokeStyle = "Black";
      fillStyle = "Black";
      drawSize = 3;
    }

    drawing_data = {
      drawxp: drawxp,
      drawyp: drawyp,
      id: id,
      pict_id: pict_id,
      DrawX: DrawX,
      drawY: drawY,
      paint: paint,
      painttype: painttype,
      draw_strokeStyle: strokeStyle,
      draw_fillStyle: fillStyle,
      drawSize: drawSize,
    };

    socket.emit("pictionary_mousemove", drawing_data);
    paint = true;
    picDraw(drawing_data);

    drawxp = DrawX;
    drawyp = drawY;
  }

  socket.on("connect", function () {
    id = socket.id;
  });

  socket.on("pictionary_id", (data) => {
    console.log("ID =" + data.id);
    pict_id = data.pict_id;
    $("#chatbox_user").text(`[ Username: ${pict_id} ]`);
    console.log(id, pict_id);
  });

  socket.on("pictionary_username", function (data) {
    let username_data = JSON.parse(data);
    username_data.set_username
      ? (pict_id = username_data.username)
      : alert("Error, username already in use.");
    notification(
      `<strong>Success:</strong> User set his <strong>username</strong> to <mark class='h5'>${pict_id}</mark>.  <em>What's up ${pict_id}</em>?!`,
      "success",
      10000
    );
  });

  socket.on("pictionary_users", function (data) {
    var userdata = JSON.parse(data);
    var userids = Object.entries(userdata);
    uis = [];
    Object.entries(userdata).forEach((i) => {
      typeof i[1].username != "undefined" ? uis.push(i[1].username) : "";
    });
    var uidstr = userids
      .map(function (k) {
        if (typeof k[1].username == "undefined") {
          return k[0];
        } else {
          return k[1].username;
        }
      })
      .join(", ");
    var users_num = userids.length;
    notification(
      `There are <strong>${users_num}</strong> users connected. ${uidstr}`,
      "primary",
      5000
    );
    pictionary_stats({
      users: users_num,
      usernames: uidstr,
      time: Date(Date.now()),
      status: "OK",
    });
  });

  socket.on("pictionary_user_disconnect", function (data) {
    console.log(data);
    if (data.discon_user != undefined) {
      user_names[data.discon_user].remove();
      pointer[data.discon_socket_id].remove();
    }
    notification(`${data.discon_user} has left.`, "info", 10000);
  });

  $("#set_my_username").click((event) => {
    uidops = {
      username: $("#username_input").val(),
    };

    socket.emit("pictionary_username", JSON.stringify(uidops));
    console.log(uidops);
    const username = $("#username_input").val();
    $("#set_username").modal("hide");
    $("#chatbox_user").text(`[Username: ${$("#username_input").val()} ]`);
    $("#chatbox_user").attr("style", "");
  });
  $("#username_input").keypress((event) => {
    if (event.which == 13) {
      event.preventDefault();
      $("#set_my_username").trigger("click");
    }
  });

  socket.on("pictionary_moving", function (data) {
    if (!(data.id in painter) || user_names[data.pict_id] === undefined) {
      pointer[data.id] = $('<div class="cursor">').appendTo("#pointer");
      if (document.getElementById(data.id) != null) {
        document.getElementById(data.id).remove();
      }
      user_names[data.pict_id] = $(`<div class='name' id=${data.id}>`)
        .text(data.pict_id)
        .appendTo("#user_names");
    }
    pointer[data.id].css({ left: data.DrawX, top: data.drawY });
    user_names[data.pict_id].css({
      left: data.DrawX + 10,
      top: data.drawY + 10,
    });
    user_names[data.pict_id].css({ color: data.draw_strokeStyle });
    user_names[data.pict_id].addClass("lead small");

    if (data.paint && painter[data.id]) {
      picDraw({
        drawxp: painter[data.id].DrawX,
        drawyp: painter[data.id].drawY,
        id: data.id,
        DrawX: data.DrawX,
        drawY: data.drawY,
        paint: data.paint,
        painttype: data.painttype,
        draw_fillStyle: data.draw_fillStyle,
        draw_strokeStyle: data.draw_strokeStyle,
        drawSize: data.drawSize,
      });
    }
    painter[data.id] = data;
    painter[data.id].updated = $.now();
  });
  var prev = {};

  socket.on("game_screenclear", function (data) {
    clearScreen(data);
  });

  setInterval(function () {
    for (ident in painter) {
      if ($.now() - painter[ident].updated > 30000) {
        pointer[ident].remove();
        if (document.getElementById(ident) != null) {
          user_names[painter[ident].pict_id].remove();
        }
        delete painter[ident];
      }
    }
  }, 30000);

  function picDraw(options) {
    if (options.painttype == "Line") {
      getC.beginPath();
      getC.strokeStyle = options.draw_strokeStyle;
      getC.lineWidth = options.drawSize;
      getC.moveTo(options.drawxp, options.drawyp);
      getC.lineTo(options.DrawX, options.drawY);
      getC.stroke();
    }
    if (options.painttype == "Dot") {
      getC.beginPath();
      getC.fillStyle = options.draw_fillStyle;
      getC.arc(
        options.DrawX,
        options.drawY,
        options.drawSize,
        0,
        Math.PI * 2,
        true
      );
      getC.fill();
    }
  }
  $("#setColors > a").click((a) => {
    a.preventDefault();
    strokeStyle = a.target.attributes.id.value.split("-")[1];
    fillStyle = a.target.attributes.id.value.split("-")[1];
    console.log(`strokeStyle: ${strokeStyle} | fillStyle: ${fillStyle}`);
  });
  $("#setType > a").click((a) => {
    a.preventDefault();
    painttype = a.target.attributes.id.value.split("-")[1];
    drawSize = a.target.attributes.id.value.split("-")[2].replace("px", "");
    console.log(`painttype: ${painttype} | drawSize: ${drawSize}`);
  });

  socket.on("chatbox", function (data) {
    let chat_data = JSON.parse(data);
    let new_chat = $(`<p id='${chat_data.id}' class='p-0 m-0'>`);
    let chatter_name = $(`<small><strong>`);
    chatter_name.text(
      String(chat_data.chat_from).padEnd(" ", 10).substr(0, 10) + ": "
    );
    chatter_name.appendTo(new_chat);
    let chatter_chat = $("<small>");
    chatter_chat.text(String(chat_data.chat_text));
    chatter_chat.appendTo(new_chat);
    $("#chatbox_area").append(new_chat);
    $("#" + chat_data.id).fadeIn(3000, "swing");
    $("#" + chat_data.id).fadeOut(3000);
  });

  $("#press_enter").click((event) => {
    socket.emit(
      "chatbox",
      JSON.stringify({ chat_text: $("#chat_enter").val() })
    );
    $("#chat_enter").val("");
  });
  $("#chat_enter").keypress((event) => {
    if (event.which == 13) {
      event.preventDefault();
      $("#press_enter").trigger("click");
    }
  });

  socket.on("pictionary_word", function (word_data) {
    notification(
      `New Word Alert: <span class='h5'>${word_data.username}</span> recieved a new word @ difficulty: <strong>${word_data.difficulty}</strong>`,
      "info",
      10000
    );
  });

  $("#get_word_modal .dropdown-item").click(function (e) {
    $("#choose_word_difficulty").text(this.innerHTML);
  });
  $("#go_get_word").click(function (e) {
    let word_difficulty = ["Easy", "Medium", "Hard", "Expert"].indexOf(
      $("#choose_word_difficulty").text()
    );
    socket.emit("pictionary_word", {
      username: "",
      difficulty: word_difficulty,
    });
    console.log(word_difficulty);
    $.ajax({
      url: "/pictionary/wordlist.json" + word_difficulty,
      dataType: "json",
      success: function (data) {
        console.log(data);
        word = JSON.parse(data).word;
        $("#word_chosen").text(`${word}`);
        $("#word_chosen").attr(
          "style",
          "text-transform:capitalize;box-shadow: 0 0 5px #51CBEE;align:right"
        );
      },
      error: function (e) {
        console.log(e);
      },
    });
  });
  let chat_noshow = false;
  $("#endChat").click(function (event) {
    event.preventDefault();
    if (!chat_noshow) {
      $("#chatbox > *").hide();
      $("#chatbox_row").show();
      $("#chatbox_row .alert-heading").attr("style", "font-size:.75em;");
      $("#endChat > span").html("&and;");
      $("#endChat").show();
      chat_noshow = true;
    } else {
      $("#chatbox > *").show();
      $("#chatbox_row .alert-heading").attr("style", "");
      $("#endChat > span").html("&or;");
      chat_noshow = false;
    }
  });

  function pictionary_stats(options) {
    console.log(options);

    $("#pictionary_STATS").html("");
    let stat_div = $("<div>")
      .addClass(`card p-0 m-2`)
      .attr("style", "width: 25rem;border:none");
    let stat_div_header = $("<div>")
      .addClass("card-title")
      .html("PICTIONARY STATS")
      .appendTo(stat_div);
    let stat_div_body = $("<div>").addClass("card-body p-0").appendTo(stat_div);
    let stat_div_row = $(`<div class='row'>`).appendTo(stat_div_body);
    for (prop in options) {
      $("<dt>")
        .addClass("col-md-4 card-text")
        .html(`<strong>${prop}</strong>`)
        .attr(
          "style",
          "text-transform:capitalize; white-space: nowrap;overflow: hidden;text-overflow: ellipsis"
        )
        .appendTo(stat_div_row);
      $("<dd>")
        .addClass("col-md-8 card-text text-muted")
        .html(`${options[prop]}`)
        .attr(
          "style",
          "text-transform:capitalize; white-space: nowrap;overflow: hidden;text-overflow: ellipsis"
        )
        .appendTo(stat_div_row);
    }
    stat_div.appendTo($("#pictionary_STATS"));
  }

  function notification(message, type, timing) {
    if (!chat_noshow) {
      $("notification").attr(
        "style",
        "padding-bottom: " + ($("#chatbox").height() + 20)
      );
      let pic_alert = $("<div>")
        .addClass(`alert alert-${type} alert-dismissable fade show`)
        .attr("role", "alert")
        .html(message)
        .appendTo($("#notification"))
        .fadeOut(timing);
    }
  }

  function clearScreen(data) {
    draw = document.getElementById("pict-page");
    const context = draw.getContext("2d");
    context.save();
    context.setTransform(1, 0, 0, 1, 0, 0);
    context.clearRect(0, 0, draw.width, draw.height);
    context.beginPath();
    console.log("cleared");
  }
  $("#clearscreen").click(function (e) {
    e.preventDefault();
    socket.emit("game_screenclear", { username: "", clear: true });
  });
}
